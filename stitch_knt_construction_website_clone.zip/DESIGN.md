---
name: Industrial Integrity
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#434656'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#737688'
  outline-variant: '#c3c5d9'
  surface-tint: '#004dea'
  primary: '#0041c8'
  on-primary: '#ffffff'
  primary-container: '#0055ff'
  on-primary-container: '#e3e6ff'
  inverse-primary: '#b6c4ff'
  secondary: '#515f78'
  on-secondary: '#ffffff'
  secondary-container: '#d2e0fe'
  on-secondary-container: '#55637d'
  tertiary: '#7b4100'
  on-tertiary: '#ffffff'
  tertiary-container: '#9e5500'
  on-tertiary-container: '#ffe2cf'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b6c4ff'
  on-primary-fixed: '#001551'
  on-primary-fixed-variant: '#0039b3'
  secondary-fixed: '#d6e3ff'
  secondary-fixed-dim: '#b9c7e4'
  on-secondary-fixed: '#0d1c32'
  on-secondary-fixed-variant: '#39475f'
  tertiary-fixed: '#ffdcc3'
  tertiary-fixed-dim: '#ffb77d'
  on-tertiary-fixed: '#2f1500'
  on-tertiary-fixed-variant: '#6e3900'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Montserrat
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Montserrat
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-lg-mobile:
    fontFamily: Montserrat
    fontSize: 28px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Montserrat
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Work Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Work Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: Work Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 48px
  section-gap: 80px
---

## Brand & Style
The design system is engineered for **777 Group LLC**, emphasizing precision, safety, and master-level craftsmanship. The brand personality is grounded in reliability and regional expertise, positioning the company as a premium electrical contractor.

The aesthetic follows a **Corporate / Modern** direction with **Industrial** accents. This means the UI is characterized by high-contrast utility, structured layouts, and clear information hierarchy. It avoids unnecessary fluff in favor of clarity, reflecting the "get it done right the first time" ethos of a professional electrical contractor. The visual language should feel as organized and dependable as a well-wired breaker panel.

## Colors
The palette is built on "Electric Blue" and "Deep Navy" to establish immediate trust and professional authority.

- **Primary (Electric Blue):** Used for primary actions, iconography, and key highlights. It represents energy and modern technology (EV chargers, smart lighting).
- **Secondary (Deep Navy):** Used for headings and high-level containers to provide a grounded, structural feel.
- **Accent (Safety Orange):** Reserved strictly for high-priority Call-to-Actions (CTAs) like "Get Free Estimate" and critical alerts. This mirrors the visual language of the electrical industry.
- **Neutrals:** A range of cool grays and a clean white background ensure the text remains legible and the interface feels spacious and modern.

## Typography
The typography system uses a pairing of **Montserrat** for headlines and **Work Sans** for body copy. 

- **Montserrat** provides an industrial, geometric weight that feels stable and modern. It should be used for all headers and major service titles.
- **Work Sans** is highly legible and professional, making it ideal for technical descriptions of electrical services and contractual details.
- **Capitalization:** Use uppercase for labels and small buttons to enhance the "utility" feel of the interface.

## Layout & Spacing
The layout utilizes a **12-column Fixed Grid** for desktop to maintain a contained, professional appearance, transitioning to a fluid single-column stack for mobile devices.

- **Rhythm:** An 8px base unit drives all padding and margin decisions. 
- **Sectioning:** Heavy vertical spacing (80px+) between service sections (e.g., Residential vs. Commercial) creates a clean, premium feel.
- **Mobile:** Margins shrink to 16px to maximize real estate for project photos and contact forms.

## Elevation & Depth
Depth in this design system is used to signify "interactivity" and "containment." 

- **Service Cards:** Use a "Low-contrast outline" combined with a very subtle ambient shadow (4% opacity Navy) to make them feel like physical panels on a wall.
- **Sticky Header:** Uses a Backdrop Blur (12px) with a 1px bottom border in Light Gray to remain present without being heavy.
- **Interactive States:** When hovering over a card or button, the shadow should deepen slightly and the element should lift by 2px, providing tactile feedback common in high-quality professional tools.

## Shapes
The shape language is **Soft (0.25rem)**. 

Electrical work is about precision and structure; therefore, oversized "pill" shapes or overly rounded corners are avoided. Small, disciplined radii suggest technical accuracy while remaining approachable. 

- **Images:** Real project photos should use the `rounded-lg` (0.5rem) token to feel polished.
- **Inputs:** Form fields for "Get an Estimate" should have sharp, clean corners (rounded-sm) to emphasize a business-like tone.

## Components
Consistent component styling ensures the brand feels reliable and established.

- **Primary CTA ("Call Now"):** High-contrast Primary Blue background with white text. Includes a phone icon prefix.
- **Accent CTA ("Get Free Estimate"):** Safety Orange background. This is the "Primary" action on the page and should stand out against the blue/navy theme.
- **Service Cards:** White background, 1px border (#E2E8F0), featuring a top-aligned project photo, Montserrat headline, and a short Work Sans description.
- **Status Indicators:** 
    - **Success:** Green outlines for successfully submitted estimate forms.
    - **Error:** Red text and 2px border for validation errors.
- **Iconography:** Use thick-stroke (2pt) geometric icons to represent services like "Panel Upgrades" (lightning bolt), "EV Chargers" (plug), and "Lighting" (bulb).